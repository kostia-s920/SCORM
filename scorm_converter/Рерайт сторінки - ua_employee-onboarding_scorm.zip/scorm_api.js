// Покращена обгортка для SCORM API
var SCORM = {
    initialized: false,
    apiHandle: null,
    version: null,
    progress: 0,
    debug: false, // Режим відлагодження вимкнено

    // Порожня функція логування (не виводить нічого)
    log: function(message, type) {
        // Логування повністю відключено
    },

    // Ініціалізація SCORM API
    init: function() {
        // Спроба знайти API кілька разів із затримкою
        var maxTries = 15;
        var tries = 0;

        var tryGetAPI = function() {
            this.apiHandle = this.getAPI();
            tries++;

            if (this.apiHandle) {
                this.initializeAPI();
            } else if (tries < maxTries) {
                setTimeout(tryGetAPI.bind(this), 200);
            }
        }.bind(this);

        tryGetAPI();
        return this.initialized;
    },

    // Ініціалізація виявленого API
    initializeAPI: function() {
        if (!this.apiHandle) {
            return false;
        }

        try {
            if (typeof this.apiHandle.Initialize !== 'undefined') {
                this.version = '2004';
                this.initialized = this.apiHandle.Initialize('');
            } else if (typeof this.apiHandle.LMSInitialize !== 'undefined') {
                this.version = '1.2';
                this.initialized = this.apiHandle.LMSInitialize('');
            } else {
                return false;
            }

            if (this.initialized) {
                // Одразу встановлюємо початковий статус
                this.setCompletionStatus('incomplete');

                // Запускаємо періодичне збереження даних
                this.startAutosave();

                return true;
            } else {
                return false;
            }
        } catch (e) {
            return false;
        }
    },

    // Автоматичне збереження даних кожні 3 хвилини
    startAutosave: function() {
        if (!this.initialized) return;

        this.autosaveInterval = setInterval(function() {
            this.commit();
        }.bind(this), 3 * 60 * 1000); // 3 хвилини
    },

    // Отримання останньої помилки
    getLastError: function() {
        if (!this.apiHandle) return 'API не знайдено';

        try {
            if (this.version === '2004') {
                var errorCode = this.apiHandle.GetLastError();
                var errorString = this.apiHandle.GetErrorString(errorCode);
                var errorDescription = this.apiHandle.GetDiagnostic(errorCode);
                return 'Код: ' + errorCode + ', ' + errorString + ' - ' + errorDescription;
            } else if (this.version === '1.2') {
                var errorCode = this.apiHandle.LMSGetLastError();
                var errorString = this.apiHandle.LMSGetErrorString(errorCode);
                var errorDescription = this.apiHandle.LMSGetDiagnostic(errorCode);
                return 'Код: ' + errorCode + ', ' + errorString + ' - ' + errorDescription;
            }
        } catch (e) {
            return 'Помилка при отриманні коду помилки: ' + e.message;
        }

        return 'Невідома помилка';
    },

    // Застосування змін, щоб LMS збереглa їх
    commit: function() {
        if (!this.initialized) return false;

        try {
            var result = false;
            if (this.version === '2004') {
                result = this.apiHandle.Commit('');
            } else if (this.version === '1.2') {
                result = this.apiHandle.LMSCommit('');
            }

            return result;
        } catch (e) {
            return false;
        }
    },

    // Завершення сесії
    terminate: function() {
        if (!this.initialized) return false;

        try {
            // Спочатку зупиняємо автозбереження
            if (this.autosaveInterval) {
                clearInterval(this.autosaveInterval);
            }

            // Перед завершенням зберігаємо дані
            this.commit();

            var result = false;
            if (this.version === '2004') {
                result = this.apiHandle.Terminate('');
            } else if (this.version === '1.2') {
                result = this.apiHandle.LMSFinish('');
            }

            if (result) {
                this.initialized = false;
                return true;
            } else {
                return false;
            }
        } catch (e) {
            return false;
        }
    },

    // Встановлення статусу завершення
    setCompletionStatus: function(status) {
        if (!this.initialized) {
            return false;
        }

        try {
            var result = false;
            if (this.version === '2004') {
                result = this.apiHandle.SetValue('cmi.completion_status', status);
                // Також встановлюємо success_status для SCORM 2004
                if (status === 'completed') {
                    this.apiHandle.SetValue('cmi.success_status', 'passed');
                }
            } else if (this.version === '1.2') {
                var statusMap = {
                    'completed': 'completed',
                    'incomplete': 'incomplete',
                    'not attempted': 'not attempted',
                    'failed': 'failed',
                    'passed': 'passed'
                };
                var mappedStatus = statusMap[status] || 'incomplete';
                result = this.apiHandle.LMSSetValue('cmi.core.lesson_status', mappedStatus);
            }

            if (result) {
                // Одразу зберігаємо встановлене значення
                this.commit();
                return true;
            } else {
                return false;
            }
        } catch (e) {
            return false;
        }
    },

    // Встановлення часу сесії в правильному форматі
    setSessionTime: function(seconds) {
        if (!this.initialized) return false;

        try {
            var result = false;
            if (this.version === '2004') {
                // Формат ISO 8601 (PT1H30M5S)
                var h = Math.floor(seconds / 3600);
                var m = Math.floor((seconds % 3600) / 60);
                var s = Math.floor(seconds % 60);
                var timeValue = 'PT';
                if (h > 0) timeValue += h + 'H';
                if (m > 0) timeValue += m + 'M';
                if (s > 0 || (h === 0 && m === 0)) timeValue += s + 'S';

                result = this.apiHandle.SetValue('cmi.session_time', timeValue);
            } else if (this.version === '1.2') {
                // Формат HH:MM:SS.S
                var h = Math.floor(seconds / 3600);
                var m = Math.floor((seconds % 3600) / 60);
                var s = seconds % 60;
                var timeValue = (h < 10 ? '0' + h : h) + ':' + 
                               (m < 10 ? '0' + m : m) + ':' + 
                               (s < 10 ? '0' + s : s);

                result = this.apiHandle.LMSSetValue('cmi.core.session_time', timeValue);
            }

            return result;
        } catch (e) {
            return false;
        }
    },

    // Отримання поточного статусу
    getCompletionStatus: function() {
        if (!this.initialized) return '';

        try {
            var status = '';
            if (this.version === '2004') {
                status = this.apiHandle.GetValue('cmi.completion_status');
            } else if (this.version === '1.2') {
                status = this.apiHandle.LMSGetValue('cmi.core.lesson_status');
            }

            return status;
        } catch (e) {
            return '';
        }
    },

    // Встановлення прогресу проходження
    setProgressMeasure: function(progress) {
        if (!this.initialized) {
            return false;
        }

        // Переконуємося, що значення прогресу в діапазоні 0-1
        progress = Math.max(0, Math.min(1, progress));
        this.progress = progress;

        try {
            var result = false;

            if (this.version === '2004') {
                result = this.apiHandle.SetValue('cmi.progress_measure', progress.toFixed(2));

                // Також встановлюємо scaled_passing_score якщо його немає
                var passingScore = this.apiHandle.GetValue('cmi.scaled_passing_score');
                if (passingScore === '' || passingScore === 'unknown') {
                    this.apiHandle.SetValue('cmi.scaled_passing_score', '0.7');
                }

                // Встановлюємо score
                this.apiHandle.SetValue('cmi.score.scaled', progress.toFixed(2));
                this.apiHandle.SetValue('cmi.score.raw', Math.round(progress * 100).toString());
                this.apiHandle.SetValue('cmi.score.min', '0');
                this.apiHandle.SetValue('cmi.score.max', '100');
            } else if (this.version === '1.2') {
                // Встановлюємо бали
                var score = Math.round(progress * 100);
                this.apiHandle.LMSSetValue('cmi.core.score.raw', score.toString());
                this.apiHandle.LMSSetValue('cmi.core.score.min', '0');
                this.apiHandle.LMSSetValue('cmi.core.score.max', '100');
                result = true;
            }

            if (result) {
                // Якщо прогрес близький до 100%, встановлюємо статус completed
                if (progress >= 0.9) {
                    this.setCompletionStatus('completed');
                }

                return true;
            } else {
                return false;
            }
        } catch (e) {
            return false;
        }
    },

    // Встановлення розташування (номер сторінки для PDF)
    setLocation: function(location) {
        if (!this.initialized) return false;

        try {
            var result = false;
            if (this.version === '2004') {
                result = this.apiHandle.SetValue('cmi.location', location);
            } else if (this.version === '1.2') {
                result = this.apiHandle.LMSSetValue('cmi.core.lesson_location', location);
            }

            return result;
        } catch (e) {
            return false;
        }
    },

    // Отримання поточного прогресу
    getProgressMeasure: function() {
        return this.progress;
    },

    // Пошук API в ієрархії фреймів
    getAPI: function() {
        var win = window;
        var foundAPI = null;
        var findAPITries = 0;
        var findAPIMaxTries = 15;

        // Функція пошуку API в конкретному вікні
        var lookForAPI = function(win) {
            // Спочатку перевіряємо наявність SCORM 2004 API
            if (win.API_1484_11) {
                return win.API_1484_11;
            }

            // Потім перевіряємо наявність SCORM 1.2 API
            if (win.API) {
                return win.API;
            }

            return null;
        }.bind(this);

        // Спочатку перевіряємо поточне вікно
        foundAPI = lookForAPI(win);
        if (foundAPI) return foundAPI;

        // Пошук API в ієрархії батьківських вікон
        while (win.parent != null && win.parent != win && findAPITries < findAPIMaxTries) {
            findAPITries++;
            win = win.parent;

            foundAPI = lookForAPI(win);
            if (foundAPI) return foundAPI;
        }

        // Пошук API у відкривачі вікна (якщо є)
        if (window.opener != null && typeof window.opener != 'undefined') {
            foundAPI = lookForAPI(window.opener);
            if (foundAPI) return foundAPI;
        }

        return null;
    }
};

// Деякі додаткові утиліти
var SCORMUtils = {
    // Відстеження часу
    startTime: new Date(),

    // Обчислення тривалості сесії в секундах
    getSessionDuration: function() {
        var currentTime = new Date();
        var sessionDuration = Math.floor((currentTime - this.startTime) / 1000);
        return sessionDuration;
    },

    // Оновлення часу сесії в SCORM
    updateSessionTime: function() {
        if (SCORM.initialized) {
            var duration = this.getSessionDuration();
            SCORM.setSessionTime(duration);
        }
    }
};

// Глобальні функції для виклику з HTML
function initializeSCORM() {
    // Встановлюємо обробники подій
    window.addEventListener('beforeunload', function() {
        terminateSCORM();
    });

    // Ініціалізація і початковий статус
    if (SCORM.init()) {
        SCORM.setCompletionStatus('incomplete');

        // Починаємо відстежувати час
        SCORMUtils.startTime = new Date();

        // Періодично оновлюємо час сесії
        setInterval(function() {
            SCORMUtils.updateSessionTime();
        }, 60000); // Кожну хвилину
    } else {
        // Спробуємо ще раз через секунду
        setTimeout(initializeSCORM, 1000);
    }
}

function terminateSCORM() {
    // Останнє оновлення часу перед завершенням
    SCORMUtils.updateSessionTime();

    // Завершення сесії
    if (SCORM.initialized) {
        SCORM.terminate();
    }
}

// Функція для оновлення прогресу
function updateSCORMProgress(progress, location) {
    if (!SCORM.initialized) {
        return;
    }

    // Встановлення прогресу
    SCORM.setProgressMeasure(progress);

    // Якщо передано розташування
    if (location !== undefined) {
        SCORM.setLocation(location);
    }

    // Зберігаємо зміни в LMS
    SCORM.commit();
}

// Пуста функція для перевірки стану SCORM
function checkSCORMStatus() {
    return {
        initialized: SCORM.initialized,
        version: SCORM.version,
        progress: SCORM.progress,
        completionStatus: SCORM.getCompletionStatus()
    };
}
